<html>
  <head>
    <title>GRS Customer Info</title>
    <link href="stylesheets/inventorystyles.css" rel="stylesheet"/>
    <link href="stylesheets/forms.css" rel="stylesheet" />
      
  </head>
<body>
  <header>
      <a href="index.php">Return Home</a>
      <img id="logo" src="picture resources/rocketpic.jpg"/>
      <h1>Customer Info</h1>
    </header>
  
	<h1>This page is still in development</h1>
  
    <table>
      <tr><td>populate with Customer name</td></tr>
      <tr><td>populate with Customer phone number</td></tr>
      <tr><td>populate with Customer street address</td></tr>
      <tr><td>populate with Customer city and state</td></tr>
      <tr><td>populate with Customer zipcode</td></tr>
    </table>
  <a href="index.php"><input type="button" value="Back" /></a>
  
  
</body>
  <footer>
    <h3>Gamma Rocket Stars</h3>
    <a href="contact_us.php">Contact Us</a>
    <a href="about_us.php">About Us</a>
    <a href="employees.php">Employees</a>
    <a href="careers.php">Careers</a>
    <p> Created by Gamma Rocket Stars, Copyright Spring 2023, for JCC Systems Concepts and Design Class </p>
  </footer>
  
</html>