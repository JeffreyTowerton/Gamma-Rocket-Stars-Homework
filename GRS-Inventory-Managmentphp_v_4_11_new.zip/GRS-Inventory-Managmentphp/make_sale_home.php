

<html>
    <head>
      <link href="stylesheets/inventorystyles.css" rel="stylesheet"/>
      <title>GRS Make Sale</title>
    </head>
  
  <body>
    <header>
      <a href="index.php">Return Home</a>
      <img id="logo" src="picture resources/rocketpic.jpg"/>
      <h1>Make Sale</h1>
    </header>

    <form action="make_sale_home.php" method="post">
      Item Number:
        <input type="text" name="itemNumber" /><br />
      Quantity:
        <input type="text" name="quantity" /><br />

  <!-- CREATE AN UNEDITABLE TEXT FIELD TO ACCUMULATE A
       RUNNING SALES TOTAL. ONE BUTTON TO ADD THAT SALE
       TO THE TOTAL, ANOTHER TO COMPLETE THE SALE ETC. -->
      <input type="submit" value="Update" />
      <input type="reset" value="Clear" />

  
    </form>
  </body>
  <footer>
    <h3>Gamma Rocket Stars</h3>
    <a href="contact_us.php">Contact Us</a>
    <a href="about_us.php">About Us</a>
    <a href="employees.php">Employees</a>
    <a href="careers.php">Careers</a>
    <p> Created by Gamma Rocket Stars, Copyright Spring 2023, for JCC Systems Concepts and Design Class </p>
  </footer>
  
</html>
