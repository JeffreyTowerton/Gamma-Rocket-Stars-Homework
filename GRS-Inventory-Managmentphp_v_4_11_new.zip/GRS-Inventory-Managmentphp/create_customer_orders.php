<?php

echo <<<_END
<html>
  <head>
    <title>GRS Create Customer Orders</title>
    <link href="stylesheets/inventorystyles.css" rel="stylesheet"/>
    <link href="stylesheets/forms.css" rel="stylesheet" />
      
  </head>
  
  <body>
    <header>
      <a href="index.php">Return Home</a>
      <img id="logo" src="picture resources/rocketpic.jpg"/>
      <h1>Enter Customer Order</h1>
    </header>
      
	  <h1>This page is still in development</h1>
	  
    <div>
      
      <p>Fill in each line item in the form below. Once all fields are filled, click, "Add To Order" to add the line item to the order.\n
        Once all items are on the order, click on "Submit Order" to generate a picking ticket to remove items from inventory and add to the invoice.
      </p>
      <form action="create_customer_order.php" method="post">
        <label>Item Number<input type="text" id="itemNumber"/></label>
        <label>Quantity<input type="number" id="quantity"/></label>
        <label>Description<input type="text" id="itemDescription"/></label>
        <label>Cost $<input type="text" id="cost"/></label>
        <label>List $<input type="text" id="list"/></label>
        <input type="submit" value="Add to Order" id="add"/>
        <input type="submit" value="Remove From Order" id="remove"/>
      </form>
      <table>
        <tr><td>insert item info here on click Add To Order</td></tr>
        <tr><td>insert item info here on click Add To Order</td></tr>
        <tr><td>insert item info here on click Add To Order</td></tr>
        <tr><td>insert item info here on click Add To Order</td></tr>
        <tr><td>insert item info here on click Add To Order</td></tr>
        <tr><td>insert item info here on click Add To Order</td></tr>
        <tr><td>insert item info here on click Add To Order</td></tr>
        <tr><td>insert item info here on click Add To Order</td></tr>
        <tr><td>insert item info here on click Add To Order</td></tr>
        <tr><td>insert item info here on click Add To Order</td></tr>
        
      </table>
      <form action="submit_to_order.php" method="post" id="submit">
        <input type="button" id="Submit_to_order" value="Submit"/>
      </form>
        
      
        
    </div>
    <a href="index.php"><input type="button" value="Back" /></a>
  </body>
  <footer>
    <h3>Gamma Rocket Stars</h3>
    <a href="contact_us.php">Contact Us</a>
    <a href="about_us.php">About Us</a>
    <a href="employees.php">Employees</a>
    <a href="careers.php">Careers</a>
    <p> Created by Gamma Rocket Stars, Copyright Spring 2023, for JCC Systems Concepts and Design Class </p>
  </footer>
</html>

_END;

/*
function addToOrder($Item_Num, $Item_Desc, $Item_Qty) {
  $query = "INSERT INTO Order VALUES" ."($Order_Number, $Line_Num, $Item_Num, $Item_Desc, $Item_Qty)"
}
// Retrieve all records from the database
	$query  = "SELECT item_num, description, quantity FROM inventory WHERE  ;
	$result = $pdo->query($query);

	while ($row = $result->fetch())
	{
		$r0 = htmlspecialchars($row['item_num']);
		$r1 = htmlspecialchars($row['description']);
		$r2 = htmlspecialchars($row['quantity']);
	

    // Insert data from database into a table
	echo "<tr><td>$r0</td><td>$r1</td><td>$r2</td></tr>";
	}
*/