<?php
	require_once 'database files/univ-login.php';

	// Attempt to login to the database
    try
	{
		$pdo = new PDO($attr, $user, $pass, $opts);
	}
	catch (PDOException $e)
	{
		throw new PDOException($e->getMessage(), (int)$e->getCode());
	}
	

echo <<<_END
<html>
    <head>
      <link href="stylesheets/inventorystyles.css" rel="stylesheet"/>
      <title>GRS Inventory Summary</title>
    </head>
  
  <body>
    <header>
      <a href="index.php">Return Home</a>
      <img id="logo" src="picture resources/rocketpic.jpg"/>
      <h1>Inventory Summary</h1>
    </header>


	<table>
	  <th>Total Items</th>
      <th>Total Quantity</th>
      <th>House Cost</th>
      <th>Sell Cost</th>
	  
_END;

	// Retrieve all records from the database
	$query  = "SELECT COUNT(item_num) AS num_records,
					  SUM(quantity) AS quant_sum,
					  SUM(buy_price) AS buy_sum,
					  SUM(sell_price) AS sell_sum
			   FROM inventory";
	$result = $pdo->query($query);

	while ($row = $result->fetch())
	{
		$r0 = htmlspecialchars($row['num_records']);
		$r1 = htmlspecialchars($row['quant_sum']);
		$r2 = htmlspecialchars($row['buy_sum']);
		$r3 = htmlspecialchars($row['sell_sum']);
		
    
		// Insert a '$' in front of the buy and sell price
		// to enhance readability
		$r2 = "$" . $r2;
		$r3 = "$" . $r3;


    // Insert data from database into a table
	echo "<tr><td>$r0</td><td>$r1</td><td>$r2</td><td>$r3</td></tr>";
	}

echo <<<_END
	</table>
	
	<button onClick='window.print()'>Print</button>
	
  </body>
  <footer>
    <h3>Gamma Rocket Stars</h3>
    <a href="contact_us.php">Contact Us</a>
    <a href="about_us.php">About Us</a>
    <a href="employees.php">Employees</a>
    <a href="careers.php">Careers</a>
    <p> Created by Gamma Rocket Stars, Copyright Spring 2023, for JCC Systems Concepts and Design Class </p>
  </footer>
  
</html>
_END;

?>


<!-- OLD CODE
<html>
  <head>
    <title>GRS Inventory Summary Reports</title>
    <link href="stylesheets/inventorystyles.css" rel="stylesheet"/>
      
  </head>
  <body>
    <header>
      <a href="index.php">Return Home</a>
      <img id="logo" src="picture resources/rocketpic.jpg"/>
      <h1>Inventory Summary Reports</h1>
    </header>

    <div>
      <input type="button" value=""
    </div>
  </body>
<footer>
    <h3>Gamma Rocket Stars</h3>
    <a href="contact_us.php">Contact Us</a>
    <a href="about_us.php">About Us</a>
    <a href="employees.php">Employees</a>
    <a href="careers.php">Careers</a>
    <p> Created by Gamma Rocket Stars, Copyright Spring 2023, for JCC Systems Concepts and Design Class </p>
  </footer>
</html>
-->