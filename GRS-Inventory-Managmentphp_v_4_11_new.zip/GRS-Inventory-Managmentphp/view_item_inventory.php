<?php
	require_once 'database files/univ-login.php';

	// Attempt to login to the database
    try
	{
		$pdo = new PDO($attr, $user, $pass, $opts);
	}
	catch (PDOException $e)
	{
		throw new PDOException($e->getMessage(), (int)$e->getCode());
	}

	// Initialize variables
	//$value = null;

	


echo <<<_END
<html>
    <head>
      <link href="stylesheets/inventorystyles.css" rel="stylesheet"/>
	  <script src="scripts/view_item_invetory.js"></script>
      <title>GRS Item Inventory</title>
    </head>
  
  <body>
    <header>
      <a href="index.php">Return Home</a>
      <a href="view_inventory_home.php"> Back</a>
      <img id="logo" src="picture resources/rocketpic.jpg"/>
      <h1>Item Inventory</h1>
    </header>


    <form action="view_item_inventory.php" method="post" onSubmit="return isValid(this)">
      <div>
	  <br />
	  <br />
      Search By: <br />
      
      <input type="radio" id="itemNum" name="searchBy" value="itemNum" checked="checked">
      <label for="itemNum">Item Number</label><br />

      <input type="radio" id="itemDesc" name="searchBy" value="itemDesc">
      <label for="itemDesc">Description</label><br />

      <input type="radio" id="quantity" name="searchBy" value="quantity">
      <label for="quantity">Quantity</label><br />

      <input type="text" name="txtValue" /><br />
        
      </div>
      
      <input type="submit" value="Search" />
      <input type="reset" value="Clear" />     
    </form>
	
	
_END;

	// Assign user provided values
	if (isset($_POST['searchBy'])) $searchBy = $_POST['searchBy'];
	if (isset($_POST['txtValue'])) $value = sanitizeString($_POST['txtValue']);

	if($_POST) {
		if($value != null) {
			echo <<<_END
			<table>
			<th>Item Number</th>
			<th>Description</th>
			<th>Restock</th>
			<th>Quanity</th>
			<th>Buy Price</th>
			<th>Sell Price</th>
			_END;
			switch($searchBy) {
				case "itemNum":
					$query  = "SELECT * FROM inventory WHERE item_num=$value";
					$result = $pdo->query($query);
					
					while ($row = $result->fetch())
					{
						$r0 = htmlspecialchars($row['item_num']);
						$r1 = htmlspecialchars($row['description']);
						$r2 = htmlspecialchars($row['restock']);
						$r3 = htmlspecialchars($row['quantity']);
						$r4 = htmlspecialchars($row['buy_price']);
						$r5 = htmlspecialchars($row['sell_price']);
					
						// Insert a '$' in front of the buy and sell price
						// to enhance readability
						$r4 = "$" . $r4;
						$r5 = "$" . $r5;

						// Insert data from database into a table
						echo "<tr><td>$r0</td><td>$r1</td><td>$r2</td><td>$r3</td><td>$r4</td><td>$r5</td></tr>";
					}
					break;
					
				case "itemDesc":
					$query  = "SELECT * FROM inventory WHERE description LIKE '%$value%'";
					$result = $pdo->query($query);
					
					while ($row = $result->fetch())
					{
						$r0 = htmlspecialchars($row['item_num']);
						$r1 = htmlspecialchars($row['description']);
						$r2 = htmlspecialchars($row['restock']);
						$r3 = htmlspecialchars($row['quantity']);
						$r4 = htmlspecialchars($row['buy_price']);
						$r5 = htmlspecialchars($row['sell_price']);
					
						// Insert a '$' in front of the buy and sell price
						// to enhance readability
						$r4 = "$" . $r4;
						$r5 = "$" . $r5;

						// Insert data from database into a table
						echo "<tr><td>$r0</td><td>$r1</td><td>$r2</td><td>$r3</td><td>$r4</td><td>$r5</td></tr>";
					}
					break;
				case "quantity":
					$query  = "SELECT * FROM inventory WHERE quantity <= $value";
					$result = $pdo->query($query);
					
					while ($row = $result->fetch())
					{
						$r0 = htmlspecialchars($row['item_num']);
						$r1 = htmlspecialchars($row['description']);
						$r2 = htmlspecialchars($row['restock']);
						$r3 = htmlspecialchars($row['quantity']);
						$r4 = htmlspecialchars($row['buy_price']);
						$r5 = htmlspecialchars($row['sell_price']);
					
						// Insert a '$' in front of the buy and sell price
						// to enhance readability
						$r4 = "$" . $r4;
						$r5 = "$" . $r5;

						// Insert data from database into a table
						echo "<tr><td>$r0</td><td>$r1</td><td>$r2</td><td>$r3</td><td>$r4</td><td>$r5</td></tr>";
					}
					break;
			}
			echo "</table>";
		}
	}


echo <<<_END
  </body>
  <footer>
    <h3>Gamma Rocket Stars</h3>
    <a href="contact_us.php">Contact Us</a>
    <a href="about_us.php">About Us</a>
    <a href="employees.php">Employees</a>
    <a href="careers.php">Careers</a>
    <p> Created by Gamma Rocket Stars, Copyright Spring 2023, for JCC Systems Concepts and Design Class </p>
  </footer>
  
</html>
_END;


// Sanitize the user input string
function sanitizeString($var)
{
	if (get_magic_quotes_gpc())
		$var = stripcslashes($var);
	$var = strip_tags($var);
	$var = htmlentities($var);
	return $var;
}
?>



<!-- OLD VERSION STILL WORKS WITH REPLIT
<html>
    <head>
      <link href="stylesheets/inventorystyles.css" rel="stylesheet"/>
      <title>GRS Item Inventory</title>
    </head>
  
  <body>
    <header>
      <a href="index.php">Return Home</a>
      <a href="view_inventory_home.php"> Back</a>
      <img id="logo" src="picture resources/rocketpic.jpg"/>
      <h1>View Items</h1>
    </header>
    <form method="post">
      <div>
      Search By: <br />
      
      <input type="radio" id="itemNum" name="searchBy" value="itemNum" checked="checked">
      <label for="itemNum">Item Number</label><br />

      <input type="radio" id="itemDesc" name="searchBy" value="itemDesc">
      <label for="itemDesc">Description</label><br />

      <input type="radio" id="quantity" name="searchBy" value="quantity">
      <label for="quantity">Quantity</label><br />

      <input type="text" name="value" /><br />
        
      </div>
      
      <input type="submit" value="Search" />
      <input type="reset" value="Clear" />
      
    </form>

    
  </body>
  <footer>
    <h3>Gamma Rocket Stars</h3>
    <a href="contact_us.php">Contact Us</a>
    <a href="about_us.php">About Us</a>
    <a href="employees.php">Employees</a>
    <a href="careers.php">Careers</a>
    <p> Created by Gamma Rocket Stars, Copyright Spring 2023, for JCC Systems Concepts and Design Class </p>
  </footer>
  
</html>
-->