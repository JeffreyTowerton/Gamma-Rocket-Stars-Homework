<html>
  <head>
    <title>GRS Place Vendor Order</title>
    <link href="stylesheets/inventorystyles.css" rel="stylesheet"/>
      
  </head>
  <body>
    <header>
      <a href="index.php">Return Home</a>
      <img id="logo" src="picture resources/rocketpic.jpg"/>
      <h1>Place Vendor Order</h1>
    </header>
	
	<h1>This page is still in development</h1>
	
      <div>
        
      </br>
        <form action="place_vendor_order.php" method="post">
          <label>Vendor Name<input type="text" id="vendor_name" /></label></br>
          <label>Vendor Number<input type="text" id="vendor_number"/></label></br>
          <label>Item Number<input type="text" id="item_number"/></label></br>
          <label>Quantity<input type="text" id="item_quantity"/></br>
          <input type="button" id="add_to_order" value="Add To Order"/>
            <input type="button" id="place_order" value="Place Order"/>
        </form>
      <table id="vendor_order">
        <tr><td>Insert Values From each line of the vendor order.</td></tr>
        <!-- INSERT DATA FROM ORDER LINES HERE. -->
      </table>

      </div>
  </body>
  <footer>
    <h3>Gamma Rocket Stars</h3>
    <a href="contact_us.php">Contact Us</a>
    <a href="about_us.php">About Us</a>
    <a href="employees.php">Employees</a>
    <a href="careers.php">Careers</a>
    <p> Created by Gamma Rocket Stars, Copyright Spring 2023, for JCC Systems Concepts and Design Class </p>
  </footer>
</html>