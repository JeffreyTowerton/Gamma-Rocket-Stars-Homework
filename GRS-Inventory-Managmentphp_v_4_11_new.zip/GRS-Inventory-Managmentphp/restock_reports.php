<html>
  <head>
  <title>GRS Item Description</title>
  <link href="stylesheets/inventorystyles.css" rel="stylesheet"/>
  </head>

<body>
  
  <header>
    <a href="index.php">Return Home</a>
    <img id="logo" src="picture resources/rocketpic.jpg"/>
    <h1>Restock Reports</h1>
  </header>

  <!-- NOT SURE IF STILL NEEDED
  <div>
    <p>Generate restock reports using the following parameters: Quantity on Hand, Desired Stock</p>
    <form action="restock_reports.php" method="post">
      <label>Quantity on Hand<input type="text" value=""/></label>
      <label>Desired Quantity<input type="text" value=0></label>
      <input type="button" value="Generate Report" />
    </form>
  -->

    <table id="inventory_report">
		<th>Item Number</th>
		<th>Description</th>
		<th>Order Quantity</th>
      <!--
      <tr><td>Insert info from report here.</td></tr>
      -->
      <?php
        
		require_once 'database files/univ-login.php';

		// Attempt to login to the database
		try
		{
			$pdo = new PDO($attr, $user, $pass, $opts);
		}
		catch (PDOException $e)
		{
			throw new PDOException($e->getMessage(), (int)$e->getCode());
		}
		
		// Retrieve all records from the database
		$query  = "SELECT item_num, description, quantity, restock FROM inventory WHERE quantity < restock";
		$result = $pdo->query($query);

		while ($row = $result->fetch())
		{
			$r0 = htmlspecialchars($row['item_num']);
			$r1 = htmlspecialchars($row['description']);
			$r2 = htmlspecialchars($row['quantity']);
			$r3 = htmlspecialchars($row['restock']);
			
			// Calculate the quantity needed to order
			$r3 = $r3 - $r2;
		

		// Insert data from database into a table
		echo "<tr><td>$r0</td><td>$r1</td><td>$r3</td></tr>";
		}
          
      ?>
    </table>
      
  </div>

  
    <button onClick='window.print()'>Print</button>

  </body>
<footer>
    <h3>Gamma Rocket Stars</h3>
    <a href="contact_us.php">Contact Us</a>
    <a href="about_us.php">About Us</a>
    <a href="employees.php">Employees</a>
    <a href="careers.php">Careers</a>
    <p> Created by Gamma Rocket Stars, Copyright Spring 2023, for JCC Systems Concepts and Design Class </p>
  </footer>
</html>



<!-- OLD CODE STILL WORKS IN REPLIT
<html>
  <head>
  <title>GRS Item Description</title>
  <link href="stylesheets/inventorystyles.css" rel="stylesheet"/>
  </head>

<body>
  
  <header>
      <a href="index.php">Return Home</a>
      <img id="logo" src="picture resources/rocketpic.jpg"/>
      <h1>Restock Reports</h1>
    </header>

  <div>
    <p>Generate restock reports using the following parameters: Quantity on Hand, Desired Stock</p>
    <form action="restock_reports.php" method="post">
      <label>Quantity on Hand<input type="text" value=""/></label>
      <label>Desired Quantity<input type="text" value=0></label>
      <input type="button" value="Generate Report" />
    </form>

    <table id="inventory_report">
      <tr><td>Insert info from report here.</td></tr>
      <php
        while (Row !eof){
        
        }
          
      ?>
    </table>
      
  </div>

  
    

  </body>
<footer>
    <h3>Gamma Rocket Stars</h3>
    <a href="contact_us.php">Contact Us</a>
    <a href="about_us.php">About Us</a>
    <a href="employees.php">Employees</a>
    <a href="careers.php">Careers</a>
    <p> Created by Gamma Rocket Stars, Copyright Spring 2023, for JCC Systems Concepts and Design Class </p>
  </footer>
</html>
-->