<html>
  <head>
    <title>GRS Inventory Managment</title>
    <link href="stylesheets/mainscreen.css" rel="stylesheet" />
    
  </head>
  <body>
    <header>
      <h1>
        Gamma Rocket Stars Inventory Managment System
      </h1>
      <img id="logo" src="picture resources/rocketpic.jpg"/>
        <p id="invinst">
          Inventory controls can be accessed from this screen. Each of these controls will allow you to modify the inventory on hand, either by receiving inventory in, or by selling it to a customer. Past invoices can be accessed using the "View Invoices" Button.
        </p>
      
      <section id="inventory_functions">
        

        <input type="button" onclick="window.location.href='view_inventory_home.php';" value="View Inventory" />
        
        <input type="button" onclick="window.location.href='receive_inventory_home.php';" value="Receive Inventory" />
        
        <input type="button" onclick="window.location.href='create_customer_orders.php';" value="Create Customer Order" />
        
        <input type="button"
          onclick="window.location.href='view_invoices.php';" value="View Invoices" /> 

        <input type="button"
          onclick="window.location.href='customer_info.php';" value="Customer Info" />  

		<input type="button" onclick="window.location.href='add_inventory_item.php';" value="Add Inventory Item" />
		  
        <img src="picture resources/laptop_inventory screen.png" alt="picture of inventory screens"/>
      </section>
    </header>
    <section>
      <h2>
        Inventory Reports
      </h2>
      <input type="button"
          onclick="window.location.href='restock_reports.php';" value="Generate Restock Reports" /> 
      
      <input type="button"
          onclick="window.location.href='neg_inv_reports.php';" value="Negative Inventory Report" />  

      <input type="button"
          onclick="window.location.href='inv_summary_reports.php';" value="Inventory Summary Report" />  
    </section>
    <section>
      <h2>
        Vendor Functions
      </h2>

      <input type="button"
          onclick="window.location.href='vendor_info.php';" value="Vendor Information" />  

      <input type="button"
          onclick="window.location.href='place_vendor_order.php';" value="Place Vendor Order" />  
      
      
    <!--
    This script places a badge on your repl's full-browser view back to your repl's cover
    page. Try various colors for the theme: dark, light, red, orange, yellow, lime, green,
    teal, blue, blurple, magenta, pink!
    -->
    <script src="https://replit.com/public/js/replit-badge.js" theme="blue" defer></script> 
  </body>
  <footer>
    <p>Gamma Rocket Stars</p>
    <a href="contact_us.php">Contact Us</a>
    <a href="about_us.php">About Us</a>
    <a href="employees.php">Employees</a>
    <a href="careers.php">Careers</a>
    <p> Created by Gamma Rocket Stars, Copyright Spring 2023, for JCC Systems Concepts and Design Class </p>
  </footer>
</html>