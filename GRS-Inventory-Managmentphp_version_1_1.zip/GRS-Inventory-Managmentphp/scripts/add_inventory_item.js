/*
	filename: add_inventory_item.js
*/


// Prevent duplicate data from being sent to the database
// on page refresh
if (window.history.replaceState) {
    window.history.replaceState(null, null, window.location.href);
}

// Validate all user entered data
function isValid(form) {
	msg = ""
	msg += validateDescription(form.description.value)
	msg += validateRestock(form.restock.value)
	msg += validateQuantity(form.quantity.value)
	msg += validateBuyPrice(form.buyPrice.value)
	msg += validateSellPrice(form.sellPrice.value)
	
	if (msg == "")
		return true
	else
		alert(msg)
		return false
}

// Validate the entered description
function validateDescription(field) {
	if (field == "")
		return "No description entered\n"
	else
		return ""
}

// Validate the entered restock
function validateRestock(field) {
	if (field == "")
		return "No restock quantity entered\n"
	else if (isNaN(field))
		return "Restock quantity must be a number\n"
	else if (field <= 1)
		return "Restock quantity must be greater than or equal to 1\n"
	else
		return ""
}

// Validate the entered quantity
function validateQuantity(field) {
	if (field == "")
		return "No quantity on hand entered\n"
	else if (isNaN(field))
		return "Quantity on hand must be a number\n"
	else if (field < 0)
		return "Quantity on hand must be greater than or equal to 0\n"
	else
		return ""
}

// Validate the entered buy price
function validateBuyPrice(field) {
	if (field == "")
		return "No purchase price entered\n"
	else if (isNaN(field))
		return "Purchase price must be a number\n"
	else if (field <= 0)
		return "Purchase price must be greater than 0\n"
	else
		return ""
}

// Validate the entered sell price
function validateSellPrice(field) {
	if (field == "")
		return "No sell price entered\n"
	else if (isNaN(field))
		return "Sell price must be a number\n"
	else if (field <= 0)
		return "Sell price must be greater than 0\n"
	else
		return ""
}