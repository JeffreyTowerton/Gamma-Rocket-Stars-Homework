/*
	filename: view_item_invetory.js
*/

// Validate all data
function isValid(form) {
	
	radioVal = form.searchBy.value
	
	msg = ""
	
	switch(radioVal) {
		case "itemNum":
			msg += validateItemNum(form.txtValue.value)
			break;
		case "itemDesc":
			msg += validateItemDescription(form.txtValue.value)
			break;
		case "quantity":
			msg += validateQuantity(form.txtValue.value)
			break;
	}
	
	
	if (msg == "")
		return true
	else
		alert(msg)
		return false
}

// Validate the item Number
function validateItemNum(field) {
	if (field == "")
		return "No item number entered\n"
	else if (isNaN(field))
		return "Item number must be a number\n"
	else
		return ""
}

// Validate the item description
function validateItemDescription(field) {
	if (field == "")
		return "No description entered\n"
	else
		return ""
}

// Validate the item quantity
function validateQuantity(field) {
	if (field == "")
		return "No quantity entered\n"
	else if (isNaN(field))
		return "Quantity must be a number\n"
	else
		return ""
}