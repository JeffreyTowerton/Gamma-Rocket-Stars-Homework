/*
	filename: receive_inventory_home.js 
*/


// Prevent duplicate data entries on page refresh
if (window.history.replaceState) {
	window.history.replaceState(null, null, window.location.href);
}

// Validate all user entered data
function isValid(form) {
	msg = ""
	msg += validateItemNumber(form.itemNumber.value)
	msg += validateQuantity(form.quantity.value)
	
	if (msg == "") 
		return true
	else
		alert(msg)
		return false
}

// Validate the item number
function validateItemNumber(field) {
	if (field == "")
		return "No item number entered\n"
	else if (isNaN(field))
		return "Item number must be a number\n"
	else
		return ""
}

// Validate the quantity
function validateQuantity(field) {
	if (field == "")
		return "No quantity entered\n"
	else if (isNaN(field))
		return "Quantity must be a number\n"
	else
		return ""
}