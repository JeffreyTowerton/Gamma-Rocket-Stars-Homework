<?php
echo <<<_END
<html>
    <head>
      <link href="stylesheets/inventorystyles.css" rel="stylesheet"/>
      <title>GRS View Inventory</title>
    </head>
  
  <body>
    <header>
      <a href="index.php">Return Home</a>
      <img id="logo" src="picture resources/rocketpic.jpg"/>
      <h1>View Inventory</h1>
    </header>

    <input type="button" onclick="window.location.href='view_all_inventory.php';" value="All Inventory" />

  <input type="button" onclick="window.location.href='view_item_inventory.php';" value="Inventory by Item" />
  </body>
  <footer>
    <h3>Gamma Rocket Stars</h3>
    <a href="contact_us.php">Contact Us</a>
    <a href="about_us.php">About Us</a>
    <a href="employees.php">Employees</a>
    <a href="careers.php">Careers</a>
    <p> Created by Gamma Rocket Stars, Copyright Spring 2023, for JCC Systems Concepts and Design Class </p>
  </footer>
  
</html>
_END;
?>