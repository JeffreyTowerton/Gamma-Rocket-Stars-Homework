<!--
	filename: add_inventory_item.php
-->

<?php
	require_once 'database files/univ-login.php';

	// Attempt to login to the database
    try
	{
		$pdo = new PDO($attr, $user, $pass, $opts);
	}
	catch (PDOException $e)
	{
		throw new PDOException($e->getMessage(), (int)$e->getCode());
	}

	
			


echo <<<_END
<html>
    <head>
      <link href="stylesheets/inventorystyles.css" rel="stylesheet"/>
	  <script src="scripts/add_inventory_item.js"></script>
      <title>GRS Add Inventory Item</title>
    </head>
  
  <body>
    <header>
      <a href="index.php">Return Home</a>
      <img id="logo" src="picture resources/rocketpic.jpg"/>
      <h1>Add Inventory Item</h1>
    </header>

  

    <form action="add_inventory_item.php" method="post" onSubmit="return isValid(this)">
      <table>
      <tr><td>Description:</td>
        <td><textarea id="description" name="description" rows="4" cols="50"></textarea></td></tr>
	  <tr><td>Restock Quantity:</td>
		<td><input type="text" name="restock" id="restock" /></td></tr>
      <tr><td>Quantity on Hand:</td>
        <td><input type="text" name="quantity" id="quantity" /></td></tr>
	  <tr><td>Purchase Price:</td>
        <td><input type="text" name="buyPrice" id="buyPrice" /></td></tr>
	  <tr><td>Sell Price:</td>
        <td><input type="text" name="sellPrice" id="sellPrice" /></td></tr>
      </table>
      <input type="submit" value="Add Item" />
      <input type="reset" value="Clear" />
    </form>
	
	<table>
_END;

// Update the database
	if (isset($_POST['description']) &&
		isset($_POST['restock']) &&
		isset($_POST['quantity']) &&
		isset($_POST['buyPrice']) &&
		isset($_POST['sellPrice'])) {
			
			$description = sanitizeString($_POST['description']);
			$restock = sanitizeString($_POST['restock']);
			$quantity = sanitizeString($_POST['quantity']);
			$buyPrice = sanitizeString($_POST['buyPrice']);
			$sellPrice = sanitizeString($_POST['sellPrice']);
			
			// Insert the new item into the inventory table
			$query = "INSERT INTO inventory VALUES" .
						"(NULL, '$description', $restock, $quantity, $buyPrice, $sellPrice)";
			$result = $pdo->query($query);
		
			
			$query = "SELECT *
						FROM inventory 
						WHERE item_num = (SELECT MAX(item_num) FROM inventory)";
			$result = $pdo->query($query);
		
			while ($row = $result->fetch())
			{
				$r0 = htmlspecialchars($row['item_num']);
				$r1 = htmlspecialchars($row['description']);
				$r2 = htmlspecialchars($row['restock']);
				$r3 = htmlspecialchars($row['quantity']);
				$r4 = htmlspecialchars($row['buy_price']);
				$r5 = htmlspecialchars($row['sell_price']);
				
				echo "<tr><th colspan='6'>Item added to inventory</th></tr><tr><th>Item Number</th><th>Description</th><th>Restock</th>
					  <th>Quantity</th><th>Buy Price</th><th>Sell Price</th></tr>
					  <tr><td>$r0</td><td>$r1</td><td>$r2</td><td>$r3</td><td>$r4</td><td>$r5</td></tr>";
			}
		
			
		}

echo <<<_END
	</table>
  </body>
  <footer>
    <h3>Gamma Rocket Stars</h3>
    <a href="contact_us.php">Contact Us</a>
    <a href="about_us.php">About Us</a>
    <a href="employees.php">Employees</a>
    <a href="careers.php">Careers</a>
    <p> Created by Gamma Rocket Stars, Copyright Spring 2023, for JCC Systems Concepts and Design Class </p>
  </footer>
  
</html>
_END;



// Sanitize the user input string
function sanitizeString($var)
{
	if (get_magic_quotes_gpc())
		$var = stripcslashes($var);
	$var = strip_tags($var);
	$var = htmlentities($var);
	return $var;
}
?>

