<?php
	require_once 'database files/univ-login.php';

	// Attempt to login to the database
    try
	{
		$pdo = new PDO($attr, $user, $pass, $opts);
	}
	catch (PDOException $e)
	{
		throw new PDOException($e->getMessage(), (int)$e->getCode());
	}

	
			


echo <<<_END
<html>
    <head>
      <link href="stylesheets/inventorystyles.css" rel="stylesheet"/>
	  <script src="scripts/receive_inventory_home.js"></script>
      <title>GRS Receive Inventory</title>
    </head>
  
  <body>
    <header>
      <a href="index.php">Return Home</a>
      <img id="logo" src="picture resources/rocketpic.jpg"/>
      <h1>Receive Inventory</h1>
    </header>

  

    <form action="receive_inventory_home.php" method="post" onSubmit="return isValid(this)">
      <table>
      <tr><td>Item Number:</td>
        <td><input type="text" name="itemNumber" id="itemNumber" /></td></tr>
      <tr><td>Quantity:</td>
        <td><input type="text" name="quantity" id="quantity" /></td></tr>
      </table>
      <input type="submit" value="Update" />
      <input type="reset" value="Clear" />
    </form>
	
	<table>
_END;

// Update the database
	if (isset($_POST['itemNumber']) &&
		isset($_POST['quantity'])) {
			
			$itemNumber = sanitizeString($_POST['itemNumber']);
			$quantity = sanitizeString($_POST['quantity']);
			
			
			$query = "SELECT item_num, quantity FROM inventory WHERE item_num = $itemNumber";
			$result = $pdo->query($query);
		
			
			while ($row = $result->fetch())
			{
				$r0 = htmlspecialchars($row['item_num']);
				$r1 = htmlspecialchars($row['quantity']);
				echo "<th></th><th>Item Number</th><th>Quantity</th><tr><td>Old</td><td>$r0</td><td>$r1</td></tr>";
			}
			
			$query = "UPDATE inventory SET quantity = quantity + $quantity WHERE item_num = $itemNumber";
			$result = $pdo->query($query);
			
			$query = "SELECT item_num, quantity FROM inventory WHERE item_num = $itemNumber";
			$result = $pdo->query($query);
			
			while ($row = $result->fetch())
			{
				$r0 = htmlspecialchars($row['item_num']);
				$r1 = htmlspecialchars($row['quantity']);
				echo "<tr><td>New</td><td>$r0</td><td>$r1</td></tr>";
			}
			
			
			// This checks the database and alerts the user if 
			// the item does not exist
			$query = "SELECT item_num, quantity FROM inventory WHERE item_num = $itemNumber";
			$result = $pdo->query($query);
			
			if (sizeOf($result->fetchAll()) < 1) { 
				echo "<script>alert('Item does not exist\\n');</script>"; 
			}
			
		}

echo <<<_END
	</table>
  </body>
  <footer>
    <h3>Gamma Rocket Stars</h3>
    <a href="contact_us.php">Contact Us</a>
    <a href="about_us.php">About Us</a>
    <a href="employees.php">Employees</a>
    <a href="careers.php">Careers</a>
    <p> Created by Gamma Rocket Stars, Copyright Spring 2023, for JCC Systems Concepts and Design Class </p>
  </footer>
  
</html>
_END;



// Sanitize the user input string
function sanitizeString($var)
{
	if (get_magic_quotes_gpc())
		$var = stripcslashes($var);
	$var = strip_tags($var);
	$var = htmlentities($var);
	return $var;
}
?>

<!--  OLD VERSION STILL WORKS WITH REPLIT
<html>
    <head>
      <link href="stylesheets/inventorystyles.css" rel="stylesheet"/>
      <title>GRS Receive Inventory</title>
    </head>
  
  <body>
    <header>
      <a href="index.php">Return Home</a>
      <img id="logo" src="picture resources/rocketpic.jpg"/>
      <h1>Receive Inventory</h1>
    </header>

    <form action="receive_inventory_home.php" method="post">
      <table>
      <tr><td>Item Number:</td>
        <td><input type="text" name="itemNumber" /></td></tr>
      <tr><td>Quantity:</td>
        <td><input type="text" name="quantity" /></td></tr>
      </table>
      <input type="submit" value="Update" />
      <input type="reset" value="Clear" />
    </form>
  </body>
  <footer>
    <h3>Gamma Rocket Stars</h3>
    <a href="contact_us.php">Contact Us</a>
    <a href="about_us.php">About Us</a>
    <a href="employees.php">Employees</a>
    <a href="careers.php">Careers</a>
    <p> Created by Gamma Rocket Stars, Copyright Spring 2023, for JCC Systems Concepts and Design Class </p>
  </footer>
  
</html>
-->
