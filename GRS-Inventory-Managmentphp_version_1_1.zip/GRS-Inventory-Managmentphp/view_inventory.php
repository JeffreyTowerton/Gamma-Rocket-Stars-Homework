
echo <<<_END
<html>
  
  <head>
  <title>GRS Item Description</title>
  <link href="stylesheets/inventorystyles.css" rel="stylesheet"/>
  </head>

<body>
  <header>
      <a href="index.php">Return Home</a>
      <img id="logo" src="picture resources/rocketpic.jpg"/>
      <h1>View Inventory</h1>
    </header>
  
</body>
 <footer>
    <h3>Gamma Rocket Stars</h3>
    <a href="contact_us.php">Contact Us</a>
    <a href="about_us.php">About Us</a>
    <a href="employees.php">Employees</a>
    <a href="careers.php">Careers</a>
    <p> Created by Gamma Rocket Stars, Copyright Spring 2023, for JCC Systems Concepts and Design Class </p>
  </footer>

echo
<tr><td>Item:</td><td class="right">$item</td>td></tr>
<tr><td>Description:</td><td class="right">$description</td>td></tr>
<tr><td>Price:</td><td class="right">$price</td>td></tr>