<?php
	require_once 'database files/univ-login.php';

	// Attempt to login to the database
    try
	{
		$pdo = new PDO($attr, $user, $pass, $opts);
	}
	catch (PDOException $e)
	{
		throw new PDOException($e->getMessage(), (int)$e->getCode());
	}
	

echo <<<_END
<html>
    <head>
      <link href="stylesheets/inventorystyles.css" rel="stylesheet"/>
      <title>GRS All Inventory</title>
    </head>
  
  <body>
    <header>
      <a href="index.php">Return Home</a>
      <a href="view_inventory_home.php"> Back</a>
      <img id="logo" src="picture resources/rocketpic.jpg"/>
      <h1>All Inventory</h1>
    </header>


	<table>
      <th>Item Number</th>
      <th>Description</th>
      <th>Restock</th>
	  <th>Quanity</th>
	  <th>Buy Price</th>
	  <th>Sell Price</th>
_END;

	// Retrieve all records from the database
	$query  = "SELECT * FROM inventory";
	$result = $pdo->query($query);

	while ($row = $result->fetch())
	{
		$r0 = htmlspecialchars($row['item_num']);
		$r1 = htmlspecialchars($row['description']);
		$r2 = htmlspecialchars($row['restock']);
		$r3 = htmlspecialchars($row['quantity']);
		$r4 = htmlspecialchars($row['buy_price']);
		$r5 = htmlspecialchars($row['sell_price']);
    
		// Insert a '$' in front of the buy and sell price
		// to enhance readability
		$r4 = "$" . $r4;
		$r5 = "$" . $r5;


    // Insert data from database into a table
	echo "<tr><td>$r0</td><td>$r1</td><td>$r2</td><td>$r3</td><td>$r4</td><td>$r5</td></tr>";
	}

echo <<<_END
	</table>
  </body>
  <footer>
    <h3>Gamma Rocket Stars</h3>
    <a href="contact_us.php">Contact Us</a>
    <a href="about_us.php">About Us</a>
    <a href="employees.php">Employees</a>
    <a href="careers.php">Careers</a>
    <p> Created by Gamma Rocket Stars, Copyright Spring 2023, for JCC Systems Concepts and Design Class </p>
  </footer>
  
</html>
_END;

?>

<!-- OLD VERSION STILL WORKS WITH REPLIT
<html>
    <head>
      <link href="stylesheets/inventorystyles.css" rel="stylesheet"/>
      <title>GRS All Inventory</title>
    </head>
  
  <body>
    <header>
      <a href="index.php">Return Home</a>
      <a href="view_inventory_home.php"> Back</a>
      <img id="logo" src="picture resources/rocketpic.jpg"/>
      <h1>View All Inventory</h1>
    </header>

    <table>
      <th>Item Number</th>
      <th>Description</th>
      <th>Quantity</th>


  

   
  </body>
  <footer>
    <h3>Gamma Rocket Stars</h3>
    <a href="contact_us.php">Contact Us</a>
    <a href="about_us.php">About Us</a>
    <a href="employees.php">Employees</a>
    <a href="careers.php">Careers</a>
    <p> Created by Gamma Rocket Stars, Copyright Spring 2023, for JCC Systems Concepts and Design Class </p>
  </footer>
  
</html>
-->

