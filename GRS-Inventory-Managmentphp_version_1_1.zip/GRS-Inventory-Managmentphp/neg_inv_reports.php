<?php
	require_once 'database files/univ-login.php';

	// Attempt to login to the database
    try
	{
		$pdo = new PDO($attr, $user, $pass, $opts);
	}
	catch (PDOException $e)
	{
		throw new PDOException($e->getMessage(), (int)$e->getCode());
	}


echo <<<_END
<html>
  <head>
    <title>GRS Negative Inventory Report</title>
    <link href="stylesheets/inventorystyles.css" rel="stylesheet"/>     
  </head>
  
  <body>
	<header>
    <a href="index.php">Return Home</a>
      <img id="logo" src="picture resources/rocketpic.jpg"/>
      <h1>Negative Inventory Report</h1>
	</header>
  
	
	
	<table>
		<th>Item Number</th>
		<th>Description</th>
		<th>Quantity</th>
_END;

	// Retrieve all records from the database
	$query  = "SELECT item_num, description, quantity FROM inventory WHERE quantity < 0";
	$result = $pdo->query($query);

	while ($row = $result->fetch())
	{
		$r0 = htmlspecialchars($row['item_num']);
		$r1 = htmlspecialchars($row['description']);
		$r2 = htmlspecialchars($row['quantity']);
	

    // Insert data from database into a table
	echo "<tr><td>$r0</td><td>$r1</td><td>$r2</td></tr>";
	}
	
	
echo <<<_END
	</table>

	<button onClick='window.print()'>Print</button>
	
  </body>
  <footer>
    <h3>Gamma Rocket Stars</h3>
    <a href='contact_us.php'>Contact Us</a>
    <a href='about_us.php'>About Us</a>
    <a href='employees.php'>Employees</a>
    <a href='careers.php'>Careers</a>
    <p> Created by Gamma Rocket Stars, Copyright Spring 2023, for JCC Systems Concepts and Design Class </p>
  </footer>
</html>
_END;
?>








<!-- OLD VERSION (STILL WORKS ON REPLIT)

<html>
  <head>
    <title>GRS Negative Inventory Report</title>
    <link href="stylesheets/inventorystyles.css" rel="stylesheet"/>
      
  </head>
  <body>
    <header>
      <a href="index.php">Return Home</a>
      <img id="logo" src="picture resources/rocketpic.jpg"/>
      <h1>Negative Inventory Report</h1>
    </header>
    <div>
      
    </div>
    
  </body>
  <footer>
    <h3>Gamma Rocket Stars</h3>
    <a href="contact_us.php">Contact Us</a>
    <a href="about_us.php">About Us</a>
    <a href="employees.php">Employees</a>
    <a href="careers.php">Careers</a>
    <p> Created by Gamma Rocket Stars, Copyright Spring 2023, for JCC Systems Concepts and Design Class </p>
  </footer>
</html>
-->



